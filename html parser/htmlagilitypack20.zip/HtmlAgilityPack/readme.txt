HTML Agility Pack V1.3.0.0

This directory contains the HtmlAgilityPack solution and source code and this readme file. The other directories are:

+ Doc			Contains the HtmlAgilityPack assembly documentation as a .CHM file
+ Samples		Contains some HtmlAgilityPack samples
 + GetDocLinks		A sample that determines all linked files and references of a givn HTML document
 + Html2Txt		A sample that converts an HTML document into a plain text .txt file
 + Html2Xml		A sample that converts an HTML document into an XML file
 + HtmlToRss		A sample that converts an HTML file into an RSS feed. Two methods are demonstrated.

Simon Mourier
June 2003