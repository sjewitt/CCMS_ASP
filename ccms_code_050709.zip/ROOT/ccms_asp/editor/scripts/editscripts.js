
/*
define tab/panel div ID mapping.
This also defines other proprties such as 
iteation length to capture the URL tab index
parameter.
[note - functions with dynamic ASP replacements are inline]
*/

/*
General tab manipulation functions:
*/

var elemList = [
  {tab:'tab1',panel:'panel1'},
  {tab:'tab2',panel:'panel2'},
  {tab:'tab3',panel:'panel3'},
  {tab:'tab4',panel:'panel4'}
  /*{tab:'tab5',panel:'panel5'}*/
  ];

function showPanel(panelId){
  var panel;
  var tab;
  for(var a=0;a<elemList.length;a++){
    panel   = document.getElementById(elemList[a].panel);
    tab     = document.getElementById(elemList[a].tab);
    panel.style.display       = "none";
    tab.style.color           = "#eee";
    tab.style.backgroundColor = "#ccc";
    if(elemList[a].panel == panelId){
      panel.style.display = "block";
      tab.style.color = "purple";
      tab.style.backgroundColor = "#999";
    }
    var out = "";
    var count = 0;
    for(p in panel.style){
      out += (p+"="+panel.style[p]+"\t");
      if(count>=10){
        count=0;
        out+="\n";
      }
    }
  }
}

//tab 1:
function setAction(action){
  document.forms["vt"].action.value = action;
  //and submit it...
}
function checkVTForm(frm){
  alert(frm.action.value);
  return false;
}

function popup(action,params){
  var urlParams = "";
  if(params) urlParams = "?"+params;
  //alert(action);
  //map action to URL:
  var actionMap             = new Object();
  actionMap.createcontent   = {url:"createcontent.asp",width:400,height:220};
  actionMap.editcontent     = {url:"editcontent.asp",width:800,height:520};
  
  var e = window.open("/ccms_asp/editor/"+actionMap[action].url+urlParams, 'win', 'scrollbars=no,toolbar=no,menubar=no,status=yes,width='+actionMap[action].width+',height='+actionMap[action].height+'')
  e.focus();
}
