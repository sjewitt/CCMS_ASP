----------------------------------------------------------------------
-- SQL script for data model creation of database 'ccms'
----------------------------------------------------------------------

create table "content" (
	"id" int identity not null,
	"name" varchar (50) not null,
	"created_date" datetime not null,
	constraint PK_content primary key clustered
	(
		id
	)
);

create table "content_version" (
	"id" int identity not null,
	"content_id" int not null,
	"version_id" int not null,
	"state_id" int not null,
	"data" text null,
	"edit_user" int not null,
	"updated_date" datetime not null,
	constraint PK_content_version primary key clustered
	(
		id
	)
);

create table "layout" (
	"id" int identity not null,
	"layout_url" varchar (255) not null,
	constraint PK_layout primary key clustered
	(
		id
	)
);

create table "page" (
	"id" int identity not null,
	"state" int not null,
	"linktext" varchar (255) not null,
	"description" varchar (255) null,
	"keywords" varchar (255) null,
	"created_user" int not null,
	"updated_user" int not null,
	"layout_id" int null,
	constraint PK_page primary key clustered
	(
		id
	)
);

create table "page_content_ref" (
	"content_id" int not null,
	"page_id" int not null
);

create table "state" (
	"id" int identity not null,
	"name" varchar (15) not null,
	"description" varchar (255) null,
	constraint PK_state primary key clustered
	(
		id
	)
);

create table "users" (
	"id" int identity not null,
	"login" varchar (50) not null,
	"fullname" varchar (255) not null,
	"email" nvarchar (50) null,
	"active" bit not null,
	"permissions" int not null default (0),
	constraint PK_users primary key clustered
	(
		id
	)
);

create table "viewtree" (
	"id" int identity not null,
	"page_id" int not null,
	"parent_id" int not null,
	"layout_id" int null,
	constraint PK_viewtree primary key clustered
	(
		id
	)
);

create table "content" (
	"id" int identity not null,
	"name" varchar (50) not null,
	"created_date" datetime not null,
	constraint PK_content primary key clustered
	(
		id
	)
);

create table "content_version" (
	"id" int identity not null,
	"content_id" int not null,
	"version_id" int not null,
	"state_id" int not null,
	"data" text null,
	"edit_user" int not null,
	"updated_date" datetime not null,
	constraint PK_content_version primary key clustered
	(
		id
	)
);

create table "layout" (
	"id" int identity not null,
	"layout_url" varchar (255) not null,
	constraint PK_layout primary key clustered
	(
		id
	)
);

create table "page" (
	"id" int identity not null,
	"state" int not null,
	"linktext" varchar (255) not null,
	"description" varchar (255) null,
	"keywords" varchar (255) null,
	"created_user" int not null,
	"updated_user" int not null,
	"layout_id" int null,
	constraint PK_page primary key clustered
	(
		id
	)
);

create table "page_content_ref" (
	"content_id" int not null,
	"page_id" int not null
);

create table "state" (
	"id" int identity not null,
	"name" varchar (15) not null,
	"description" varchar (255) null,
	constraint PK_state primary key clustered
	(
		id
	)
);

create table "users" (
	"id" int identity not null,
	"login" varchar (50) not null,
	"fullname" varchar (255) not null,
	"email" nvarchar (50) null,
	"active" bit not null,
	"permissions" int not null default (0),
	constraint PK_users primary key clustered
	(
		id
	)
);

create table "viewtree" (
	"id" int identity not null,
	"page_id" int not null,
	"parent_id" int not null,
	"layout_id" int null,
	constraint PK_viewtree primary key clustered
	(
		id
	)
);

